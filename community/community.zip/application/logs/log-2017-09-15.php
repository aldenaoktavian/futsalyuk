<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-15 16:19:46 --> SUKSES login member dengan id 9 , IP Address : ::1
