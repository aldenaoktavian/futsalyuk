<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-25 13:23:14 --> SUKSES login member dengan id 2 , IP Address : ::1
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined offset: 20 E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 164
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:25:57 --> Severity: Notice --> Undefined variable: team_image E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 166
ERROR - 2017-09-25 13:26:12 --> Severity: Notice --> Undefined offset: 20 E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 164
ERROR - 2017-09-25 13:26:53 --> Severity: Warning --> implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 173
ERROR - 2017-09-25 13:28:13 --> Severity: Warning --> implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 174
