<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-24 14:31:06 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-24 14:31:13 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-24 14:31:14 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-24 14:31:25 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-24 14:32:36 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-24 14:32:37 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-24 14:32:43 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-24 14:36:53 --> SUKSES login member dengan id 2 , IP Address : ::1
