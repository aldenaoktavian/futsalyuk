<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-26 19:53:59 --> Severity: Warning --> mysqli::real_connect() [<a href='mysqli.real-connect'>mysqli.real-connect</a>]: [2002] A connection attempt failed because the connected party did not properly respond after a period of time, or established connecti (trying to connect via tcp://futsalyuk.com:3306) E:\xampp\htdocs\futsalyuk\social\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-26 19:53:59 --> Severity: Warning --> mysqli::real_connect() [<a href='mysqli.real-connect'>mysqli.real-connect</a>]: (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 E:\xampp\htdocs\futsalyuk\social\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-26 19:53:59 --> Unable to connect to the database
ERROR - 2017-08-26 22:18:52 --> 404 Page Not Found: Resgiter/index
ERROR - 2017-08-26 22:19:01 --> 404 Page Not Found: Register/index
ERROR - 2017-08-26 23:02:59 --> 404 Page Not Found: Img/a4.jpg
ERROR - 2017-08-26 23:02:59 --> 404 Page Not Found: Img/a7.jpg
ERROR - 2017-08-26 23:02:59 --> 404 Page Not Found: Img/profile.jpg
ERROR - 2017-08-26 23:02:59 --> 404 Page Not Found: Img/profile_small.jpg
ERROR - 2017-08-26 23:02:59 --> 404 Page Not Found: Img/profile_small.jpg
ERROR - 2017-08-26 23:02:59 --> 404 Page Not Found: Img/profile.jpg
ERROR - 2017-08-26 23:02:59 --> 404 Page Not Found: Img/a7.jpg
ERROR - 2017-08-26 23:02:59 --> 404 Page Not Found: Img/a4.jpg
ERROR - 2017-08-26 23:03:05 --> 404 Page Not Found: Img/a7.jpg
ERROR - 2017-08-26 23:03:05 --> 404 Page Not Found: Img/profile.jpg
ERROR - 2017-08-26 23:03:05 --> 404 Page Not Found: Img/profile_small.jpg
ERROR - 2017-08-26 23:03:05 --> 404 Page Not Found: Img/a4.jpg
ERROR - 2017-08-26 23:03:12 --> 404 Page Not Found: Img/profile_small.jpg
ERROR - 2017-08-26 23:03:12 --> 404 Page Not Found: Img/a7.jpg
ERROR - 2017-08-26 23:03:12 --> 404 Page Not Found: Img/a4.jpg
ERROR - 2017-08-26 23:03:12 --> 404 Page Not Found: Img/profile.jpg
ERROR - 2017-08-26 23:04:04 --> 404 Page Not Found: Img/profile.jpg
ERROR - 2017-08-26 23:04:04 --> 404 Page Not Found: Img/profile_small.jpg
ERROR - 2017-08-26 23:04:04 --> 404 Page Not Found: Img/a4.jpg
ERROR - 2017-08-26 23:04:04 --> 404 Page Not Found: Img/a7.jpg
ERROR - 2017-08-26 23:05:36 --> 404 Page Not Found: Img/profile.jpg
ERROR - 2017-08-26 23:05:36 --> 404 Page Not Found: Img/a7.jpg
ERROR - 2017-08-26 23:05:36 --> 404 Page Not Found: Img/profile_small.jpg
ERROR - 2017-08-26 23:05:36 --> 404 Page Not Found: Img/a4.jpg
ERROR - 2017-08-26 23:06:32 --> 404 Page Not Found: Img/a7.jpg
ERROR - 2017-08-26 23:06:32 --> 404 Page Not Found: Img/profile.jpg
ERROR - 2017-08-26 23:06:32 --> 404 Page Not Found: Img/profile_small.jpg
ERROR - 2017-08-26 23:06:32 --> 404 Page Not Found: Img/a4.jpg
