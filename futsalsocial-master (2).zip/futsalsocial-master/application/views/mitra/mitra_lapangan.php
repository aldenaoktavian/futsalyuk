<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Mitra Lapangan Futsalyuk</title>
</head>
<body>
	
</body>
</html>