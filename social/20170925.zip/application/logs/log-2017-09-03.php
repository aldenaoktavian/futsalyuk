<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-03 01:14:29 --> Severity: Parsing Error --> syntax error, unexpected T_IS_NOT_EQUAL, expecting ',' or ')' E:\xampp\htdocs\futsalyuk\social\application\controllers\Register.php 19
ERROR - 2017-09-03 01:42:53 --> Severity: Notice --> Undefined index: register_booking E:\xampp\htdocs\futsalyuk\social\application\controllers\Register.php 58
ERROR - 2017-09-03 01:42:54 --> Severity: Notice --> Undefined index: register_booking E:\xampp\htdocs\futsalyuk\social\application\controllers\Register.php 58
ERROR - 2017-09-03 01:43:18 --> Severity: Notice --> Undefined index: register_booking E:\xampp\htdocs\futsalyuk\social\application\controllers\Register.php 59
ERROR - 2017-09-03 03:57:47 --> Severity: Parsing Error --> syntax error, unexpected T_VARIABLE E:\xampp\htdocs\futsalyuk\social\application\models\Member_model.php 69
ERROR - 2017-09-03 03:57:47 --> Severity: Parsing Error --> syntax error, unexpected T_VARIABLE E:\xampp\htdocs\futsalyuk\social\application\models\Member_model.php 69
ERROR - 2017-09-03 03:59:58 --> Severity: Notice --> Undefined index: member_image E:\xampp\htdocs\futsalyuk\social\application\controllers\Register.php 20
ERROR - 2017-09-03 03:59:58 --> Severity: Notice --> Undefined index: member_banner E:\xampp\htdocs\futsalyuk\social\application\controllers\Register.php 35
ERROR - 2017-09-03 03:59:58 --> SUKSES login member dengan id  , IP Address : ::1
ERROR - 2017-09-03 03:59:59 --> SUKSES login member dengan id  , IP Address : ::1
ERROR - 2017-09-03 04:00:00 --> 404 Page Not Found: Bootstrap-selectjsmap/index
ERROR - 2017-09-03 04:00:01 --> 404 Page Not Found: WNumbminjsmap/index
ERROR - 2017-09-03 04:00:50 --> 404 Page Not Found: Home/index
ERROR - 2017-09-03 04:00:56 --> 404 Page Not Found: Timeline/index
ERROR - 2017-09-03 04:03:01 --> Severity: Notice --> Undefined index: member_image E:\xampp\htdocs\futsalyuk\social\application\controllers\Register.php 20
ERROR - 2017-09-03 04:03:01 --> Severity: Notice --> Undefined index: member_banner E:\xampp\htdocs\futsalyuk\social\application\controllers\Register.php 35
ERROR - 2017-09-03 04:03:02 --> SUKSES login member dengan id  , IP Address : ::1
ERROR - 2017-09-03 04:03:02 --> SUKSES login member dengan id  , IP Address : ::1
ERROR - 2017-09-03 04:03:02 --> 404 Page Not Found: Bootstrap-selectjsmap/index
ERROR - 2017-09-03 04:03:02 --> 404 Page Not Found: WNumbminjsmap/index
ERROR - 2017-09-03 04:06:24 --> SUKSES login member dengan id  , IP Address : ::1
ERROR - 2017-09-03 04:07:28 --> Severity: Notice --> Undefined index: is_team_admin E:\xampp\htdocs\futsalyuk\social\application\controllers\Register.php 79
ERROR - 2017-09-03 04:07:28 --> SUKSES login member dengan id 6 , IP Address : ::1
ERROR - 2017-09-03 04:07:38 --> 404 Page Not Found: Uploadfiles/member-images
ERROR - 2017-09-03 04:23:56 --> Query error: Table 'futsalyuk-20170827.login_log' doesn't exist - Invalid query: UPDATE `login_log` SET `login_datetime` = '2017-09-03 04:23:56', `status` = 1
WHERE `member_id` = '6'
ERROR - 2017-09-03 04:28:00 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-03 04:28:16 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-03 04:28:16 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-03 04:28:16 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-03 04:28:17 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-03 04:28:28 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-03 04:28:46 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-03 04:31:17 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-03 04:31:21 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-03 04:32:04 --> GAGAL Login , IP Address : ::1
ERROR - 2017-09-03 04:33:09 --> Severity: Notice --> Undefined index: is_team_admin E:\xampp\htdocs\futsalyuk\social\application\controllers\Login.php 34
ERROR - 2017-09-03 04:33:09 --> SUKSES login member dengan id 5 , IP Address : ::1
ERROR - 2017-09-03 04:33:10 --> 404 Page Not Found: Uploadfiles/member-images
ERROR - 2017-09-03 04:36:39 --> Severity: Notice --> Undefined index: is_team_admin E:\xampp\htdocs\futsalyuk\social\application\controllers\Register.php 79
ERROR - 2017-09-03 04:36:39 --> SUKSES login member dengan id 7 , IP Address : ::1
ERROR - 2017-09-03 04:37:52 --> SUKSES login member dengan id 8 , IP Address : ::1
ERROR - 2017-09-03 04:44:21 --> Query error: Unknown column 'c9f0f895fb98ab9159f51fd0297e236d' in 'where clause' - Invalid query: SELECT a.member_id, a.user_id, team_id, CONCAT(member_social_firstname, ' ', member_social_lastname) AS member_name, member_image, member_banner, is_team_admin, username, password, email FROM member_social a INNER JOIN user b ON a.user_id = b.id_user WHERE md5(a.member_id) = c9f0f895fb98ab9159f51fd0297e236d
ERROR - 2017-09-03 04:47:40 --> Severity: Notice --> Undefined variable: partner_detail E:\xampp\htdocs\futsalyuk\social\application\views\message.php 62
ERROR - 2017-09-03 04:47:40 --> Severity: Notice --> Undefined variable: partner_detail E:\xampp\htdocs\futsalyuk\social\application\views\message.php 70
ERROR - 2017-09-03 04:47:54 --> Severity: Notice --> Undefined index: member_banner E:\xampp\htdocs\futsalyuk\social\application\helpers\futsal_helper.php 18
ERROR - 2017-09-03 04:47:55 --> Severity: Notice --> Undefined index: member_name E:\xampp\htdocs\futsalyuk\social\application\views\includes\member-banner.php 18
ERROR - 2017-09-03 04:47:55 --> Severity: Notice --> Undefined index: member_name E:\xampp\htdocs\futsalyuk\social\application\views\includes\member-banner.php 19
ERROR - 2017-09-03 04:48:20 --> SUKSES login member dengan id  , IP Address : ::1
ERROR - 2017-09-03 04:48:36 --> SUKSES login member dengan id  , IP Address : ::1
ERROR - 2017-09-03 04:48:40 --> SUKSES login member dengan id  , IP Address : ::1
ERROR - 2017-09-03 04:50:08 --> SUKSES login member dengan id 7 , IP Address : ::1
