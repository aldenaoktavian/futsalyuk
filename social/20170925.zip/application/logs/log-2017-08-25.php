<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-25 18:12:48 --> Severity: Warning --> include_once(analyticstracking.php) [<a href='function.include-once'>function.include-once</a>]: failed to open stream: No such file or directory E:\xampp\htdocs\futsalyuk\social\application\views\login.php 150
ERROR - 2017-08-25 18:12:48 --> Severity: Warning --> include_once() [<a href='function.include'>function.include</a>]: Failed opening 'analyticstracking.php' for inclusion (include_path='.;\xampp\php\PEAR') E:\xampp\htdocs\futsalyuk\social\application\views\login.php 150
ERROR - 2017-08-25 18:14:02 --> Severity: Error --> Call to undefined function parent_base_url() E:\xampp\htdocs\futsalyuk\social\application\views\login.php 24
ERROR - 2017-08-25 18:20:55 --> 404 Page Not Found: Assets/img
ERROR - 2017-08-25 18:20:55 --> 404 Page Not Found: Assets/img
ERROR - 2017-08-25 18:20:55 --> 404 Page Not Found: Assets/img
ERROR - 2017-08-25 18:20:55 --> 404 Page Not Found: Assets/img
ERROR - 2017-08-25 21:39:31 --> Severity: Warning --> mysqli::real_connect() [<a href='mysqli.real-connect'>mysqli.real-connect</a>]: [2002] A connection attempt failed because the connected party did not properly respond after a period of time, or established connecti (trying to connect via tcp://futsalyuk.com:3306) E:\xampp\htdocs\futsalyuk\social\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-25 21:39:31 --> Severity: Warning --> mysqli::real_connect() [<a href='mysqli.real-connect'>mysqli.real-connect</a>]: (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 E:\xampp\htdocs\futsalyuk\social\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-25 21:39:31 --> Unable to connect to the database
ERROR - 2017-08-25 21:41:57 --> Severity: Warning --> mysqli::real_connect() [<a href='mysqli.real-connect'>mysqli.real-connect</a>]: [2002] A connection attempt failed because the connected party did not properly respond after a period of time, or established connecti (trying to connect via tcp://futsalyuk.com:3306) E:\xampp\htdocs\futsalyuk\social\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-25 21:41:57 --> Severity: Warning --> mysqli::real_connect() [<a href='mysqli.real-connect'>mysqli.real-connect</a>]: (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 E:\xampp\htdocs\futsalyuk\social\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-25 21:41:57 --> Unable to connect to the database
ERROR - 2017-08-25 21:42:12 --> Severity: Warning --> mysqli::real_connect() [<a href='mysqli.real-connect'>mysqli.real-connect</a>]: [2002] A connection attempt failed because the connected party did not properly respond after a period of time, or established connecti (trying to connect via tcp://futsalyuk.com:3306) E:\xampp\htdocs\futsalyuk\social\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-25 21:42:12 --> Severity: Warning --> mysqli::real_connect() [<a href='mysqli.real-connect'>mysqli.real-connect</a>]: (HY000/2002): A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond.
 E:\xampp\htdocs\futsalyuk\social\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-08-25 21:42:12 --> Unable to connect to the database
