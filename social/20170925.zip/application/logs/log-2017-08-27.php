<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-27 00:55:37 --> 404 Page Not Found: Assets/css
ERROR - 2017-08-27 00:56:02 --> 404 Page Not Found: Assets/css
ERROR - 2017-08-27 00:56:20 --> 404 Page Not Found: Assets/css
ERROR - 2017-08-27 00:56:21 --> 404 Page Not Found: Assets/css
ERROR - 2017-08-27 15:49:01 --> Severity: Notice --> Undefined variable: result E:\xampp\htdocs\futsalyuk\social\application\controllers\Register.php 31
ERROR - 2017-08-27 16:41:21 --> Severity: Notice --> Undefined index: member_image E:\xampp\htdocs\futsalyuk\social\application\controllers\Register.php 18
ERROR - 2017-08-27 16:45:10 --> Severity: Notice --> Undefined index: member_image E:\xampp\htdocs\futsalyuk\social\application\controllers\Register.php 18
ERROR - 2017-08-27 16:51:50 --> Severity: Notice --> Undefined index: member_image E:\xampp\htdocs\futsalyuk\social\application\controllers\Register.php 18
