<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-09-01 12:08:33 --> 404 Page Not Found: Daftar/index
