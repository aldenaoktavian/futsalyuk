    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs12">
                <div class="all_team">
                    <div class="sngl_team">   
                        <div class="team_item">                  
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                        <div class="team_item">
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                    </div>
                    <div class="sngl_team">   
                        <div class="team_item">                  
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                        <div class="team_item">
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                    </div>
                    <div class="sngl_team">   
                        <div class="team_item">                  
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                        <div class="team_item">
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                    </div>
                    <div class="sngl_team">   
                        <div class="team_item">                  
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                        <div class="team_item">
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                    </div>
                    <div class="sngl_team">   
                        <div class="team_item">                  
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                        <div class="team_item">
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                    </div>
                    <div class="sngl_team">   
                        <div class="team_item">                  
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                        <div class="team_item">
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                    </div>
                    <div class="sngl_team">   
                        <div class="team_item">                  
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                        <div class="team_item">
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                    </div>
                    <div class="sngl_team">   
                        <div class="team_item">                  
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                        <div class="team_item">
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                    </div>
                    <div class="sngl_team">   
                        <div class="team_item">                  
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                        <div class="team_item">
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                    </div>
                    <div class="sngl_team">   
                        <div class="team_item">                  
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                        <div class="team_item">
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                    </div>
                    <div class="sngl_team">   
                        <div class="team_item">                  
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                        <div class="team_item">
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                    </div>
                    <div class="sngl_team">   
                        <div class="team_item">                  
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                        <div class="team_item">
                            <img class="img-circle" src="http://wedesignthemes.com/themes/dt-mountcool/wp-content/uploads/2015/10/img-1.png" alt=""/>  
                            <h2>1</h2>
                            <h3>Team Coba</h3>
                        </div>
                    </div>
                </div>          
            </div>
        </div>
    </div>