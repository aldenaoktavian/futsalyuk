    <style type="text/css">
        .all_team img {
            width: 100%;
            max-width: 80px;
        }
        .team_item {
            min-height: 162px;
        }
    </style>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs12">
                <div class="all_team">
                    <?php echo $data_rangking; ?>
                </div>  
                <a href="<?php echo base_url(); ?>social/all_rangking" style="float: right;margin-right: 18px;">Lihat Semua Rangking</a>
            </div>
        </div>
    </div>