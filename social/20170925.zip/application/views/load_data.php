<?php if(isset($page_type)){ ?>

<?php } ?>