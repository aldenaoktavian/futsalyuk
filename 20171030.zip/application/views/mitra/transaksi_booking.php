<html>
    <div class="x_content">
      <div class="container_box">
        <h3>Transaksi Booking</h3><br/>
        <div class="col-md-4">
          <input type="text" class="form-control datepicker" id="startdate" placeholder="Tanggal Mulai">
        </div>
        <div class="col-md-4 hidden">
          <input type="text" class="form-control datepicker" id="enddate" placeholder="Tanggal">
        </div>
        <div class="col-md-4">
          <button class="btn btn-primary" onclick="lihat_transaksi()">Lihat Transaksi</button>
        </div>
        <br/><br/><br/><br/>
        <div class="clearfix"></div>
      </div>
      <div id="transaksi_booking">
      </div>
  	</div>
</html>