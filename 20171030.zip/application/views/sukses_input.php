<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Input Lapangan</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="<?php echo base_url()?>assets/img/favicon/favicon.png">
	<!-- Include jQuery Mobile stylesheets -->
	<link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">

	<!-- Include the jQuery library -->
	<script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

	<!-- Include the jQuery Mobile library -->
	<script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
</head>
<body>
	<div data-role="page">
	  <div data-role="header">
	    <h1>Input Lapangan</h1>
	  </div>

	  <div data-role="main" class="ui-content">
	    
		<h3>Sukses</h3>
		<a href="<?php echo base_url() ?>input_lapangan">kembali</a>

	  </div>

	  
	</div> 
</body>
</html>